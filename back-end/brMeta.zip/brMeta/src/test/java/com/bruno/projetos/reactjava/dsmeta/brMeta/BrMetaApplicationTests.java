package com.bruno.projetos.reactjava.dsmeta.brMeta;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BrMetaApplicationTests {

	@Test
	void contextLoads() {
	}

}
