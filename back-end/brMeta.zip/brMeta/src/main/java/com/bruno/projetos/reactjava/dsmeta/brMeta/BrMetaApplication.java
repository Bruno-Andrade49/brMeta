package com.bruno.projetos.reactjava.dsmeta.brMeta;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BrMetaApplication {

	public static void main(String[] args) {
		SpringApplication.run(BrMetaApplication.class, args);
	}

}
